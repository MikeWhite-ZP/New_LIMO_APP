import ContactSection from "@/components/ContactSection";

export default function Contact() {
  return (
    <div className="min-h-screen">
      <ContactSection />
    </div>
  );
}
